#!/bin/bash

StackName=SlackInviter

S3BucketArtifacts=slackinviteb

S3PrefixArtifacts=cloudformation/slack-invite-automation

CommunityName="Hacker Lab "
SlackUrl=thehackerlab.slack.com
SlackToken=xoxp-420229646870-422232492658-720718994833-64bff74c9fccfeb7833c2e52cec19265
InviteToken=null
RecaptchaSiteKey=null
RecaptchaSecretKey=null
Locale=en

